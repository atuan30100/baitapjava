const products = [
    { name: 'Bút bi', quantity: 123 },
    { name: 'Bút chì', quantity: 165 },
    { name: 'Bút màu', quantity: 170 },
];
const tongSoLuong = (arr) => {
    return arr.reduce((sum, product) => sum + product.quantity, 0);
};
console.log(tongSoLuong(products));

//c2
const sanPhamMax = (arr) => {
    return arr.reduce((max, product) => {
        return product.quantity > max.quantity ? product : max;
    });
};
console.log(sanPhamMax(products));

//c3
const productList1 = [
    { name: 'Cá hồi', price: 250 },
];
const productList2 = [
    { name: 'Cá tầm', price: 350 },
    { name: 'Cá lăng', price: 180 },
];
const gop = (...lists) => {
    return [].conca(...lists);
};

console.log(gop(productList1, productList2));